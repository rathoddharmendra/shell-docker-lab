| Syntax       | Meaning                       
| ------------ | ----------------------------- 
| `$(command)` | run command and return output - new subshell 
| `(commands)` | run commands in subshell      
| `$((math))`  | arithmetic calculation        
| `(a b c)`    | array                         
| `{1..10}`    | spread operator like 


touch -d -- to create files with old timestamp

find . -mtime +90 -exec ls -l {} \; -- in exec command - {} is the placeholder from previous command every file discovered , and \ before ; is to escape it.

# creates more files
for file in {1..10}; do touch -d "2025-12-11T02:02:12" $file; done

# Backup - 
tar -cvf ../data/bckup.tar ~/Documents/Dee/code/shell-docker-lab/
# compress backup tar using gunzip
gzip ../data/bckup.tar 